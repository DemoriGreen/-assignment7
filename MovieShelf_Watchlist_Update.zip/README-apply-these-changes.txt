MovieShelf watchlist update

Included files:
- src/contexts/MovieContext.jsx (new)
- src/pages/Watchlist.jsx (new)
- src/App.jsx (updated)
- src/components/Header.jsx (updated)
- src/components/MovieCard.jsx (updated)

These files assume the project source lives in a folder named src and that components, pages, services, and utils are inside it. The public repository listing seems to show a different layout, so compare paths with your local project before copying.

After merging:
1. Keep your existing Home, Favorites, MovieModal, movieService, and favorites utility files.
2. Confirm imports match your folder structure.
3. Run npm install if needed, then npm run dev if your project uses Vite.
4. Test add/remove, /watchlist, refresh persistence, favorites, and movie details.
5. Commit and push after the app runs correctly.

This package does not modify GitHub automatically and has not been tested against the full local project.
